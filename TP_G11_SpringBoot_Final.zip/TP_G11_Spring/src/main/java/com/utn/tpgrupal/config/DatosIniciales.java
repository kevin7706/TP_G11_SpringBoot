package com.utn.tpgrupal.config;

import com.utn.tpgrupal.entities.Articulo;
import com.utn.tpgrupal.entities.AuditoriaApp;
import com.utn.tpgrupal.entities.Cliente;
import com.utn.tpgrupal.entities.CondicionIva;
import com.utn.tpgrupal.entities.Contacto;
import com.utn.tpgrupal.entities.Domicilio;
import com.utn.tpgrupal.entities.FacturaVenta;
import com.utn.tpgrupal.entities.FacturaVentaDetalle;
import com.utn.tpgrupal.entities.ListaPrecio;
import com.utn.tpgrupal.entities.ListaPrecioArticulo;
import com.utn.tpgrupal.entities.Marca;
import com.utn.tpgrupal.entities.PuntoVenta;
import com.utn.tpgrupal.entities.Rubro;
import com.utn.tpgrupal.entities.TipoMoneda;
import com.utn.tpgrupal.entities.Usuario;
import jakarta.persistence.EntityManager;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class DatosIniciales implements CommandLineRunner {
    private final EntityManager entityManager;

    public DatosIniciales(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    @Transactional
    public void run(String... args) {
        if (entityManager.createQuery("SELECT COUNT(u) FROM Usuario u", Long.class).getSingleResult() > 0) {
            return;
        }

        Usuario usuario = new Usuario();
        usuario.setUsuario("jperez");
        usuario.setClave("123456");
        usuario.setNombre("Juan");
        usuario.setApellido("Perez");
        entityManager.persist(usuario);

        PuntoVenta puntoVenta = new PuntoVenta();
        puntoVenta.setNumero(1);
        puntoVenta.setDescripcion("Sucursal Central");
        puntoVenta.setTipoEmision("Factura Electronica");
        puntoVenta.setDomicilioComercial("Mendoza");
        guardarAuditado(puntoVenta, usuario);

        CondicionIva condicionIva = new CondicionIva();
        condicionIva.setCodigoAfip(1);
        condicionIva.setDenominacion("Responsable Inscripto");
        guardarAuditado(condicionIva, usuario);

        TipoMoneda moneda = new TipoMoneda();
        moneda.setCodigoAfip("PES");
        moneda.setDenominacion("Pesos Argentinos");
        moneda.setSimbolo("$");
        guardarAuditado(moneda, usuario);

        Rubro rubro = new Rubro();
        rubro.setCodigo(1);
        rubro.setDenominacion("Informatica");
        guardarAuditado(rubro, usuario);

        Marca marca = new Marca();
        marca.setCodigo(1);
        marca.setDenominacion("Logitech");
        guardarAuditado(marca, usuario);

        ListaPrecio lista = new ListaPrecio();
        lista.setCodigo("LP-01");
        lista.setDenominacion("Lista General");
        guardarAuditado(lista, usuario);

        Articulo teclado = crearArticulo("ART-001", "Teclado Logitech", rubro, marca, usuario);
        Articulo mouse = crearArticulo("ART-002", "Mouse Logitech", rubro, marca, usuario);
        ListaPrecioArticulo precioTeclado = crearPrecio(lista, teclado, 15000, usuario);
        ListaPrecioArticulo precioMouse = crearPrecio(lista, mouse, 10000, usuario);

        Contacto contacto = new Contacto();
        contacto.setEmail("cliente@utn.edu.ar");
        contacto.setTelefono("261-4000000");
        contacto.setCelular("261-5000000");
        entityManager.persist(contacto);
        Domicilio domicilio = new Domicilio();
        domicilio.setNombreCalle("San Martin");
        domicilio.setNumeroCalle("100");
        entityManager.persist(domicilio);

        Cliente cliente = new Cliente();
        cliente.setCuitCuil("20-12345678-9");
        cliente.setDenominacion("Cliente UTN");
        cliente.setContacto(contacto);
        cliente.setDomicilio(domicilio);
        guardarAuditado(cliente, usuario);

        crearFactura(1001L, fecha(2026, 3, 15), "EMITIDA", 25000, puntoVenta, cliente,
                condicionIva, moneda, usuario, precioTeclado, precioMouse);
        crearFactura(1002L, fecha(2026, 3, 20), "EMITIDA", 15000, puntoVenta, null,
                condicionIva, moneda, usuario, precioTeclado);
        crearFactura(1003L, fecha(2026, 3, 25), "ANULADA", 10000, puntoVenta, cliente,
                condicionIva, moneda, usuario, precioMouse);
    }

    private Articulo crearArticulo(String codigo, String denominacion, Rubro rubro, Marca marca, Usuario usuario) {
        Articulo articulo = new Articulo();
        articulo.setCodigo(codigo);
        articulo.setDenominacion(denominacion);
        articulo.setRubro(rubro);
        articulo.setMarca(marca);
        guardarAuditado(articulo, usuario);
        return articulo;
    }

    private ListaPrecioArticulo crearPrecio(ListaPrecio lista, Articulo articulo, double precio, Usuario usuario) {
        ListaPrecioArticulo relacion = new ListaPrecioArticulo();
        relacion.setListaPrecio(lista);
        relacion.setArticulo(articulo);
        relacion.setPrecioVenta(precio);
        guardarAuditado(relacion, usuario);
        return relacion;
    }

    private void crearFactura(Long numero, Date fecha, String estado, double total, PuntoVenta puntoVenta,
            Cliente cliente, CondicionIva condicionIva, TipoMoneda moneda, Usuario usuario,
            ListaPrecioArticulo... precios) {
        FacturaVenta factura = new FacturaVenta();
        factura.setNumero(numero);
        factura.setFechaEmision(fecha);
        factura.setEstado(estado);
        factura.setImporteTotal(total);
        factura.setImporteCobrado(total);
        factura.setImporteSaldo(0);
        factura.setPuntoVenta(puntoVenta);
        factura.setCliente(cliente);
        factura.setCondicionIva(condicionIva);
        factura.setTipoMoneda(moneda);
        auditar(factura, usuario);

        factura.setDetalles(new ArrayList<>());
        for (ListaPrecioArticulo precio : precios) {
            FacturaVentaDetalle detalle = new FacturaVentaDetalle();
            detalle.setFactura(factura);
            detalle.setListaPrecioArticulo(precio);
            detalle.setDescripcion(precio.getArticulo().getDenominacion());
            detalle.setCantidad(1);
            detalle.setPrecioUnitario(precio.getPrecioVenta());
            detalle.setImporteNeto(precio.getPrecioVenta());
            detalle.setImporteSubtotal(precio.getPrecioVenta());
            factura.getDetalles().add(detalle);
        }
        entityManager.persist(factura);
    }

    private void guardarAuditado(AuditoriaApp entidad, Usuario usuario) {
        auditar(entidad, usuario);
        entityManager.persist(entidad);
    }

    private void auditar(AuditoriaApp entidad, Usuario usuario) {
        Date ahora = new Date();
        entidad.setFechaAlta(ahora);
        entidad.setFechaModificacion(ahora);
        entidad.setUsuarioCarga(usuario);
        entidad.setUsuarioModificacion(usuario);
    }

    private Date fecha(int anio, int mes, int dia) {
        return Date.from(LocalDate.of(anio, mes, dia).atStartOfDay(ZoneId.systemDefault()).toInstant());
    }
}
