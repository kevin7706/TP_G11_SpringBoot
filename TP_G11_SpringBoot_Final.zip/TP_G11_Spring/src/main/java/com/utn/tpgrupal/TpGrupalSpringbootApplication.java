package com.utn.tpgrupal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpGrupalSpringbootApplication {
    public static void main(String[] args) {
        SpringApplication.run(TpGrupalSpringbootApplication.class, args);
    }
}
