package com.utn.tpgrupal.service;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.utn.tpgrupal.dto.FacturaReporteDTO;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class FacturaService {
    private final EntityManager entityManager;

    public FacturaService(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Transactional(readOnly = true)
    public List<FacturaReporteDTO> buscarFacturasFiltradas(
            Date fechaDesde, Date fechaHasta, String estado, Double montoMinimo) {
        StringBuilder jpql = new StringBuilder("""
                SELECT new com.utn.tpgrupal.dto.FacturaReporteDTO(
                    f.numero, f.fechaEmision, COALESCE(c.denominacion, 'Consumidor Final'),
                    ci.denominacion, pv.descripcion, f.importeTotal, COUNT(d)
                )
                FROM FacturaVenta f
                LEFT JOIN f.cliente c
                JOIN f.condicionIva ci
                JOIN f.puntoVenta pv
                JOIN f.detalles d
                WHERE 1 = 1
                """);
        Map<String, Object> parametros = new HashMap<>();

        if (fechaDesde != null) {
            jpql.append(" AND f.fechaEmision >= :fechaDesde");
            parametros.put("fechaDesde", fechaDesde);
        }
        if (fechaHasta != null) {
            jpql.append(" AND f.fechaEmision <= :fechaHasta");
            parametros.put("fechaHasta", fechaHasta);
        }
        if (estado != null && !estado.isBlank()) {
            jpql.append(" AND f.estado = :estado");
            parametros.put("estado", estado);
        }
        if (montoMinimo != null) {
            jpql.append(" AND f.importeTotal >= :montoMinimo");
            parametros.put("montoMinimo", montoMinimo);
        }

        jpql.append(" GROUP BY f.id, f.numero, f.fechaEmision, c.denominacion, "
                + "ci.denominacion, pv.descripcion, f.importeTotal ORDER BY f.fechaEmision");

        TypedQuery<FacturaReporteDTO> query = entityManager.createQuery(
                jpql.toString(), FacturaReporteDTO.class);
        parametros.forEach(query::setParameter);
        return query.getResultList();
    }

    @Transactional(readOnly = true)
    public byte[] generarReporteExcel(Date fechaDesde, Date fechaHasta, String estado, Double montoMinimo) {
        List<FacturaReporteDTO> facturas = buscarFacturasFiltradas(fechaDesde, fechaHasta, estado, montoMinimo);
        StringBuilder contenido = new StringBuilder(
                "Numero\tFecha\tCliente\tCondicion IVA\tPunto de venta\tTotal\tCantidad de items\n");
        for (FacturaReporteDTO factura : facturas) {
            contenido.append(factura.getNumeroFactura()).append('\t')
                    .append(formatearFecha(factura.getFechaEmision())).append('\t')
                    .append(factura.getClienteDenominacion()).append('\t')
                    .append(factura.getCondicionIva()).append('\t')
                    .append(factura.getPuntoVentaDescripcion()).append('\t')
                    .append(factura.getImporteTotal()).append('\t')
                    .append(factura.getCantidadItems()).append('\n');
        }
        return contenido.toString().getBytes(StandardCharsets.UTF_8);
    }

    @Transactional(readOnly = true)
    public byte[] generarReportePdf(Date fechaDesde, Date fechaHasta, String estado, Double montoMinimo) {
        List<FacturaReporteDTO> facturas = buscarFacturasFiltradas(fechaDesde, fechaHasta, estado, montoMinimo);
        try (ByteArrayOutputStream salida = new ByteArrayOutputStream()) {
            Document documento = new Document();
            PdfWriter.getInstance(documento, salida);
            documento.open();
            documento.add(new Paragraph("Reporte de facturas"));
            PdfPTable tabla = new PdfPTable(7);
            for (String encabezado : new String[]{"Numero", "Fecha", "Cliente", "IVA", "Punto de venta", "Total", "Items"}) {
                tabla.addCell(encabezado);
            }
            for (FacturaReporteDTO factura : facturas) {
                tabla.addCell(String.valueOf(factura.getNumeroFactura()));
                tabla.addCell(formatearFecha(factura.getFechaEmision()));
                tabla.addCell(factura.getClienteDenominacion());
                tabla.addCell(factura.getCondicionIva());
                tabla.addCell(factura.getPuntoVentaDescripcion());
                tabla.addCell(String.valueOf(factura.getImporteTotal()));
                tabla.addCell(String.valueOf(factura.getCantidadItems()));
            }
            documento.add(tabla);
            documento.close();
            return salida.toByteArray();
        } catch (DocumentException e) {
            throw new RuntimeException("Error al generar el PDF", e);
        } catch (Exception e) {
            throw new RuntimeException("Error inesperado al generar el PDF", e);
        }
    }

    private String formatearFecha(Date fecha) {
        return fecha == null ? "" : new SimpleDateFormat("yyyy-MM-dd").format(fecha);
    }
}
