package com.utn.tpgrupal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.utn.tpgrupal.dto.FacturaReporteDTO;
import com.utn.tpgrupal.service.FacturaService;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacturaServiceTest {
    @Autowired
    private FacturaService facturaService;

    @Test
    void devuelveReporteConCantidadDeItemsYConsumidorFinal() {
        List<FacturaReporteDTO> reporte = facturaService.buscarFacturasFiltradas(null, null, "EMITIDA", null);

        assertEquals(2, reporte.size());
        assertTrue(reporte.stream().anyMatch(factura -> factura.getCantidadItems() == 2));
        assertTrue(reporte.stream().anyMatch(factura -> "Consumidor Final".equals(factura.getClienteDenominacion())));
    }

    @Test
    void filtraPorMontoMinimo() {
        List<FacturaReporteDTO> reporte = facturaService.buscarFacturasFiltradas(null, null, null, 20000.0);

        assertEquals(1, reporte.size());
        assertEquals(1001L, reporte.get(0).getNumeroFactura());
    }
}
