# Consultas JPQL del TP grupal

La clase `JPQLConsultas` implementa las 20 consignas del TP con JPQL sobre los nombres de las entidades y atributos Java del proyecto. Las consultas parametrizadas usan parámetros nombrados. Las proyecciones con más de un dato devuelven `Tuple`, cuyos alias se indican en cada método.

## Uso

Con un `EntityManager` abierto:

```java
JPQLConsultas consultas = new JPQLConsultas(em);

List<FacturaVenta> facturas = consultas.todasLasFacturas();
List<FacturaVenta> porFecha = consultas.facturasEntreFechas(desde, hasta);

for (Tuple fila : consultas.datosPrincipalesDeFacturas()) {
    Long numero = fila.get("numero", Long.class);
    Date fecha = fila.get("fechaEmision", Date.class);
    Double importe = fila.get("importeTotal", Double.class);
}

Tuple resumen = consultas.resumenFacturasEmitidas();
Long cantidad = resumen.get("cantidad", Long.class);
Double suma = (Double) resumen.get("suma");
Double promedio = (Double) resumen.get("promedio");
```

Los métodos que reciben argumentos dejan que la aplicación provea los filtros solicitados. Para el resumen agregado, `SUM` y `AVG` pueden ser `null` si no hay facturas emitidas.

## Correspondencia con las consignas

| N.º | Método |
| --- | --- |
| 1 | `todasLasFacturas()` |
| 2 | `datosPrincipalesDeFacturas()` |
| 3 | `articulosPorRubro(denominacionRubro)` |
| 4 | `facturasEntreFechas(desde, hasta)` |
| 5 | `facturasEmitidasNoAnuladasSobre(importeMinimo)` |
| 6 | `buscarClientes(texto)` |
| 7 | `estadosDeFacturas()` |
| 8 | `resumenFacturasEmitidas()` |
| 9 | `puntosDeVentaPorNumeros(numeros)` |
| 10 | `facturasCargadasPor(nombreUsuario)` |
| 11 | `detallesPorNumeroDePuntoVenta(numeroPuntoVenta)` |
| 12 | `articulosYMarcas()` |
| 13 | `facturasConArticulosDeMarca(denominacionMarca)` |
| 14 | `facturasSobreElPromedio()` |
| 15 | `totalesPorPuntoDeVenta()` |
| 16 | `usuariosConMasDeFacturas(minimoExclusivo)` |
| 17 | `ventasAgrupadasPorMarca()` |
| 18 | `marcasConVentas()` |
| 19 | `articulosSinVentas()` |
| 20 | `categoriasDeFacturas()` |

## Alias de proyecciones

- Consigna 2: `numero`, `fechaEmision`, `importeTotal`.
- Consigna 8: `cantidad`, `suma`, `promedio`.
- Consigna 12: `articulo`, `marca` (la marca es `null` si el artículo no tiene una).
- Consigna 15: `puntoVenta`, `cantidadFacturas`, `totalFacturado`.
- Consigna 16: `usuario`, `cantidad`.
- Consigna 17: `marca`, `unidades`, `subtotal`.
- Consigna 20: `numero`, `importeTotal`, `categoria`.

Los atributos del modelo difieren de algunos nombres ilustrativos del enunciado: el cliente usa `denominacion`; la marca se alcanza desde el detalle por `listaPrecioArticulo.articulo.marca`; y el punto de venta sólo se vincula a facturas desde `FacturaVenta.puntoVenta`.
